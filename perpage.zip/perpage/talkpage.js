document.addEventListener("DOMContentLoaded", () => {
    const chatForm = document.getElementById("chat-form");
    const messageContainer = document.getElementById("message-container");

    chatForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        // Get the selected message and user IDs
        const selectedMessage = document.getElementById("predefined-message").value;
        const toUserId = document.getElementById("to_user-id").value;

        // Simulate sending the message to the server
        const messageHTML = `
            <div class="message from-user">
                <p>${selectedMessage}</p>
            </div>
        `;
        messageContainer.innerHTML += messageHTML;

        // Scroll to the bottom
        messageContainer.scrollTop = messageContainer.scrollHeight;

        // Simulate backend API call or database insertion
        const response = await fetch("send_message.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: to_user_id=${toUserId}&message=${encodeURIComponent(selectedMessage)}
        });

        const result = await response.text();
        console.log(result); // Show success response
    });
});